# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['parse_onliner', 'parse_onliner.discount_bot']

package_data = \
{'': ['*']}

install_requires = \
['aiogram>=2.23.1,<3.0.0', 'bs4>=0.0.1,<0.0.2', 'requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'parse-onliner',
    'version': '0.1.0',
    'description': 'TG bot for parsing notebook store',
    'long_description': None,
    'author': 'Mikhail Orlov',
    'author_email': 'crazyminer398@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
